package com.codebrew.vipcartsdriver.utils

import android.content.Context
import android.content.Intent
import android.net.Uri

object IntentActionUtils
{
    fun dialPhone(context: Context, phoneNumber: String)
    {
        val intent = Intent(Intent.ACTION_DIAL, Uri.fromParts("tel", phoneNumber, null))
        context.startActivity(intent)
    }
  /*  fun sendEmail(context: Context, email: String)
    {
        val emailIntent = Intent(Intent.ACTION_SENDTO)
        emailIntent.data = Uri.parse("mailto:$email")
        context.startActivity(Intent.createChooser(emailIntent, context.getString(R.string.send_via)))
    }

    fun openUrl(context: Context, url: String)
    {
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
        context.startActivity(intent)
    }

    fun dialPhone(context: Context, phoneNumber: String)
    {
        val intent = Intent(Intent.ACTION_DIAL, Uri.fromParts("tel", phoneNumber, null))
        context.startActivity(intent)
    }*/
}