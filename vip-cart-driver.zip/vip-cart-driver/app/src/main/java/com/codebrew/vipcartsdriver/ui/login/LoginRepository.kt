package com.codebrew.vipcartsdriver.ui.login

import android.databinding.adapters.NumberPickerBindingAdapter.setValue
import android.arch.lifecycle.MutableLiveData
import android.arch.lifecycle.LiveData
import com.codebrew.vipcartsdriver.model.ApiResponse
import com.codebrew.vipcartsdriver.model.LoginRequest
import com.codebrew.vipcartsdriver.model.ResponseLogin
import com.codebrew.vipcartsdriver.network.RetrofitClient
import com.codebrew.vipcartsdriver.utils.NetworkResponse
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response


class LoginRepository{

    fun login(request: LoginRequest) : MutableLiveData<NetworkResponse<*>>{
        val data = MutableLiveData<NetworkResponse<*>>()

        RetrofitClient.getApi().login(request).enqueue(object :Callback<ApiResponse<ResponseLogin>>{
            override fun onFailure(call: Call<ApiResponse<ResponseLogin>>?, t: Throwable?) {
                data.value=NetworkResponse(NetworkResponse.FAILURE,null,"Error")
            }

            override fun onResponse(call: Call<ApiResponse<ResponseLogin>>?,
                                    response: Response<ApiResponse<ResponseLogin>>?) {
                if(response?.isSuccessful==true)
                    data.value=NetworkResponse(NetworkResponse.SUCCESS,response.body()?.getData(),"")
                else
                    data.value=NetworkResponse(NetworkResponse.FAILURE,null,"Error")
            }
        })
        return data
    }


    companion object {

        private var INSTANCE: LoginRepository? = null

        @JvmStatic fun getInstance() =
                INSTANCE ?: synchronized(LoginRepository::class.java) {
                    INSTANCE ?: LoginRepository()
                            .also { INSTANCE = it }
                }

        @JvmStatic fun destroyInstance() {
            INSTANCE = null
        }
    }
}