package com.codebrew.vipcartsdriver.ui.login

import android.app.Application
import android.arch.core.util.Function
import android.arch.lifecycle.AndroidViewModel
import android.arch.lifecycle.LiveData
import android.arch.lifecycle.MutableLiveData
import android.arch.lifecycle.MediatorLiveData
import android.arch.lifecycle.Transformations.switchMap
import android.support.annotation.StringRes
import com.codebrew.vipcartsdriver.R
import android.arch.lifecycle.ViewModel
import android.arch.lifecycle.ViewModelProvider
import com.codebrew.vipcartsdriver.model.*
import com.codebrew.vipcartsdriver.model.bookingItem.PastItemModel
import com.codebrew.vipcartsdriver.model.bookingItem.ResponseBooking
import com.codebrew.vipcartsdriver.utils.*
import java.text.SimpleDateFormat
import java.util.*
import kotlin.collections.ArrayList


class LoginViewModel(context: Application,
                     private val loginRepository: LoginRepository) :
        AndroidViewModel(context) {
    private lateinit var networkResponseMutableLiveData: MutableLiveData<NetworkResponse<*>>
    private var loginResponseMediatorLiveData = MediatorLiveData<ResponseLogin>()
    val snackbarMessage = SingleLiveEvent<Int>()
    private val loading = MutableLiveData<Boolean>()

    fun getLoginData(request: LoginRequest): LiveData<ResponseLogin> {
        loading.value = true
        networkResponseMutableLiveData = loginRepository.login(request)

        return switchMap(networkResponseMutableLiveData,
                Function<NetworkResponse<*>, LiveData<ResponseLogin>>() {
                    if (it?.status == NetworkResponse.SUCCESS) {
                        loading.value = false
                        if (it.data != null) {
                            PrefsManager.get().save(PrefsManager.PREF_API_TOKEN,
                                    "bearer"+" "+ch((it.data as ResponseLogin).accessToken))
                            PrefsManager.get().save(PrefsManager.PREF_USER_PROFILE,
                                    getFormattedProfileData(it.data))
                            loginResponseMediatorLiveData.value = (it.data as ResponseLogin?)
                        }
                    } else if (it?.status == NetworkResponse.FAILURE) {
                        loading.value = false
                    }
                    return@Function loginResponseMediatorLiveData
                })
    }

    private fun getFormattedProfileData(responseLogin: ResponseLogin): ProfileData {
        return ProfileData(responseLogin.firstName,
                responseLogin.lastName,responseLogin.email,
                responseLogin.countryId,responseLogin.phoneNumber,
                getAge(responseLogin.dob),
                responseLogin.imageUrl,
                getFormattedBookingItem(responseLogin.past),
                responseLogin.isBlocked)
    }

    private fun getFormattedBookingItem(past: List<PastItem?>?): ArrayList<PastItemModel> {
        val pastItemModelList= ArrayList<PastItemModel>()
        past?.forEach {
            pastItemModelList.add(PastItemModel(getFormattedDate(it?.date),getFormattedData((it?.bookings))))
        }

        return pastItemModelList
    }

    private fun getFormattedDate(date: Long?): String? {
        var dayTime=""
        val simpleDateFormat = SimpleDateFormat("MMM dd '.' yyyy", Locale.ENGLISH)
        try{
            dayTime= simpleDateFormat.format(date)
        }
        catch(e:Exception){
            e.printStackTrace()
        }
        return dayTime
    }

    private fun getFormattedData(data: ArrayList<ResponseBooking>?): ArrayList<Booking>{
        val dataFormatted=ArrayList<Booking>()
        data?.forEach { dataFormatted.add(getBooking(it))}
        return dataFormatted
    }

    private fun getBooking(bookingItem: ResponseBooking): Booking {
        return Booking(pickupTime = getTime(bookingItem.pickUpDate),
                dropOffTme = getTime(bookingItem.dropOffDate),
                pickupAddress = bookingItem.pickUpAddress,
                dropOffAddress = bookingItem.dropOffAddress,
                name = bookingItem.userId?.firstName+" "+bookingItem.userId?.lastName,
                bookingId = bookingItem.id,
                listImages = ch(bookingItem.documents),
                contact = ch(bookingItem.userId?.countryCode+bookingItem.userId?.phoneNumber),
                latlng = ch(bookingItem.userId?.location),
                status = ch(bookingItem.status),
                statusFormatted = ch(getBookingStatus(bookingItem.status)),
                statusChange = ch(getChangedBookingStatus(bookingItem.status)),
                serviceTypeActual = ch(bookingItem.carId?.serviceId?.code),
                serviceType = ch(getServiceType(bookingItem.carId?.serviceId?.code))
        )
    }

    private fun getServiceType(code: Int?): Int? {
        return when(code){
            AppConstants.SELECTED_CAR_SERVICE->{
                (R.string.service_car_rent)
            }
            AppConstants.SELECTED_CHAUFFEUR_SERVICE->{
                (R.string.service_chauffer)
            }
            else->{
                (R.string.service_limo)
            }
        }
    }

    private fun getBookingStatus(status: String?): Int? {
        return when(status){
            AppConstants.STATUS_PENDING->{
                (R.string.service_pending)
            }
            AppConstants.STATUS_CONFIRMED->{
                (R.string.service_confirmed)
            }
            AppConstants.STATUS_CANCELLED->{
                (R.string.service_cancelled)
            }
            else->{
                (R.string.service_completed)
            }
        }
    }

    private fun getChangedBookingStatus(status: String?): Int? {
        return when(status){
            AppConstants.STATUS_PENDING,AppConstants.STATUS_CONFIRMED->{
                (R.string.service_start_trip)
            }
            AppConstants.STATUS_STARTED->{
                (R.string.service_end_trip)
            }
            else->{
                (R.string.service_completed_trip)
            }
        }
    }

    private fun getTime(time: Long?): String{
        var dayTime=""
        val simpleDateFormat = SimpleDateFormat("MMM dd'\n'hh:mm a", Locale.ENGLISH)
        try{
            dayTime= simpleDateFormat.format(time)
        }
        catch(e:Exception){
            e.printStackTrace()
        }
        return dayTime
    }


    private fun getAge(dobString: String?): String {
        var ageInt=0
        try {
            val format = SimpleDateFormat("MM/dd/yyyy", Locale.US)
            val date = format.parse(dobString)
            val dob = Calendar.getInstance()
            val today = Calendar.getInstance()
            dob.time = date
            var age = today.get(Calendar.YEAR) - dob.get(Calendar.YEAR)
            if (today.get(Calendar.DAY_OF_YEAR) < dob.get(Calendar.DAY_OF_YEAR)) {
                age--
            }
            ageInt = age
        }
        catch (e:Exception){
            e.printStackTrace()
        }
        return ageInt.toString()
    }

    fun setLoading(): MutableLiveData<Boolean> {
        return loading
    }

    fun checkValidation(request: LoginRequest): Boolean {
        if (ValidationsUtils.checkForEmpty(request.email)) {
            showSnackbarMessage(R.string.login_empty_email)
            return false
        } else if (!ValidationsUtils.validateEmail(request.email)) {
            showSnackbarMessage(R.string.login_invalid_email)
            return false
        } else if (ValidationsUtils.checkForEmpty(request.password)) {
            showSnackbarMessage(R.string.login_empty_password)
            return false
        } else if (!ValidationsUtils.validatePassword(request.password)) {
            showSnackbarMessage(R.string.login_invalid_password)
            return false
        }
        return true
    }

    private fun showSnackbarMessage(@StringRes message: Int) {
        snackbarMessage.value = message
    }


    class Factory(private val application: Application, private val loginRepository:
    LoginRepository) : ViewModelProvider.NewInstanceFactory() {

        override fun <T : ViewModel> create(modelClass: Class<T>): T {

            return LoginViewModel(application, loginRepository) as T
        }
    }
}