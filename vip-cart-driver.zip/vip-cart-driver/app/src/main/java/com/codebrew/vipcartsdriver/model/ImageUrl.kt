package com.codebrew.vipcartsdriver.model

import com.google.gson.annotations.SerializedName

data class ImageUrl(

	@field:SerializedName("thumbnail")
	val thumbnail: String? = null,

	@field:SerializedName("original")
	val original: String? = null
)