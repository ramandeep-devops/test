package com.codebrew.vipcartsdriver.ui.login

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import com.codebrew.vipcartsdriver.R
import android.arch.lifecycle.ViewModelProviders
import android.databinding.DataBindingUtil
import android.support.design.widget.Snackbar
import android.widget.Toast
import com.codebrew.vipcartsdriver.databinding.ActivityLoginBinding
import com.codebrew.vipcartsdriver.model.LoginRequest
import com.codebrew.vipcartsdriver.ui.home.HomeActivity
import com.codebrew.vipcartsdriver.utils.*
import kotlinx.android.synthetic.main.activity_login.*


class LoginActivity : AppCompatActivity() {

    private lateinit var mLoginViewModel: LoginViewModel
    private lateinit var loadingDialog: LoadingDialog
    private lateinit var binding:ActivityLoginBinding

    private fun login() {
        val email = etEmail.text.toString().trim()
        val password = etPassword.text.toString().trim()
        val request = LoginRequest(email, password, "ANDROID",  PrefsManager.get().getString(PrefsManager.PREF_DEVICE_TOKEN,""))
        //check internet connection
        if (mLoginViewModel.checkValidation(request)) {
            mLoginViewModel.getLoginData(request).observeForever {
                it.let {
                    openHomeActivity()
                }
            }
        }
    }

    private fun openHomeActivity() {
        HomeActivity.start(this)
        onBackPressed()
    }

    private fun setLoading(isLoading: Boolean?) {
        loadingDialog.setLoading(isLoading ?: false)
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if(!PrefsManager.get().getString(PrefsManager.PREF_API_TOKEN,"").isEmpty()){
            HomeActivity.start(this)
            onBackPressed()
        }
        binding = DataBindingUtil.setContentView<ActivityLoginBinding>(this@LoginActivity,
                R.layout.activity_login)

        val factory = LoginViewModel.Factory(
                application, LoginRepository.getInstance())

        mLoginViewModel = ViewModelProviders.of(
                this, factory).get(LoginViewModel::class.java)

        mLoginViewModel.let {
            binding.root.setupSnackbar(this, it.snackbarMessage, Snackbar.LENGTH_SHORT)
        }

        loadingDialog = LoadingDialog(this)

        btnSignIn.setOnClickListener {
            login()
        }

        mLoginViewModel.setLoading().observeForever {
            setLoading(it)
        }

    }
}
