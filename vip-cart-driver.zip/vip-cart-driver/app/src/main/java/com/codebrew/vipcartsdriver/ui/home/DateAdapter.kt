package com.codebrew.vipcartsdriver.ui.home

import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.codebrew.vipcartsdriver.databinding.ItemDateBinding
import com.codebrew.vipcartsdriver.model.DateItem


class DateAdapter(private val homeViewModel: HomeViewModel
) : RecyclerView.Adapter<DateAdapter.ViewHolder>() {

    private var dateList = ArrayList<DateItem>()
    private lateinit var binding: ItemDateBinding
    override fun onCreateViewHolder(parent: ViewGroup?, viewType: Int): ViewHolder {
        binding = ItemDateBinding.inflate(LayoutInflater.from(parent?.context), parent,
                false)
        return ViewHolder(binding.root, homeViewModel, binding)
    }

    override fun getItemCount(): Int = dateList.size

    override fun onBindViewHolder(holder: ViewHolder?, position: Int) {
        holder?.bind(dateList[position])
    }

    inner class ViewHolder(item: View, homeViewModel: HomeViewModel,
                           private val binding: ItemDateBinding) : RecyclerView.ViewHolder(item) {
        private lateinit var dateItem: DateItem
        private lateinit var userActionsListener: DateItemSelectedListener
        init {
                userActionsListener = object : DateItemSelectedListener {
                        override fun onDateSelected(day: String) {
                            if(!dateItem.isSelected && adapterPosition!=-1) {
                                dateList.map { it.isSelected = false }
                                dateList[adapterPosition].isSelected = true
                                notifyDataSetChanged()
                                homeViewModel.onDateChange(day)
                            }
                        }
                    }
        }

        fun bind(dateItem: DateItem) {
            this.dateItem = dateItem
            with(binding) {
                dateData = dateItem
                listener=userActionsListener
                executePendingBindings()
            }

        }

    }

    fun setDateList(dateList: ArrayList<DateItem>) {
        this.dateList.clear()
        this.dateList.addAll( dateList)
        notifyDataSetChanged()
    }

}