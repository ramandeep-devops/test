package com.codebrew.vipcartsdriver.utils

import android.text.TextUtils


object ValidationsUtils{

    private const val REGEX_FIRST_NAME="[a-zA-Z]*"
    private const val REGEX_LAST_NAME="[a-zA-z]+([ '-][a-zA-Z]+)*"
    private const val REGEX_FULL_NAME="^\\p{L}+[\\p{L}\\p{Z}\\p{P}]*"
    private const val REGEX_PHONE_NUMBER="[0-9]*"

    fun validateEmail(email: String): Boolean
       = android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()

    fun validateFirstName(name: String): Boolean
       = name.matches(Regex(REGEX_FIRST_NAME))

    fun validateLastName(name: String): Boolean
       = name.matches(Regex(REGEX_LAST_NAME))

    fun validateFullName(name: String): Boolean
       = name.matches(Regex(REGEX_FULL_NAME))

    fun validatePhoneNumber(phoneNumber: String): Boolean{
        return if(phoneNumber.matches(Regex(REGEX_PHONE_NUMBER))){
            phoneNumber.length!=10 && phoneNumber.toLong() != 0L
        }
        else{
            false
        }
    }

    fun validatePassword(password: String): Boolean
    {
        if(password.length<6){
            return false
        }
        return true
    }

    fun checkForEmpty(text: String): Boolean{
        return TextUtils.isEmpty(text)
    }
}