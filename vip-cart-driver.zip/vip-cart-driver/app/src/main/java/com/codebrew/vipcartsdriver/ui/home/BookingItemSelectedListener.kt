package com.codebrew.vipcartsdriver.ui.home

import com.codebrew.vipcartsdriver.model.Booking


interface BookingItemSelectedListener {
    fun onBookingSelected(bookingItem: Booking)
    fun onAddDoc(bookingId: String?)
    fun onStatusChange(bookingItem: Booking)
    fun onCallClicked(number: String)
    fun onDirectionsClicked(latlng: ArrayList<Double>)
}