package com.codebrew.vipcartsdriver.utils.location

import android.app.IntentService
import android.content.Intent

import com.codebrew.vipcartsdriver.utils.PrefsManager
import com.google.android.gms.location.LocationResult


class LocationUpdatesIntentService : IntentService(TAG) {

    override fun onHandleIntent(intent: Intent?) {
        if (intent != null) {
            val action = intent.action
            if (ACTION_PROCESS_UPDATES == action) {
                val result = LocationResult.extractResult(intent)
                if (result != null) {
                    val locations = result.locations
                    val lat: Double
                    val lng: Double
                    if (locations.size > 0) {
                        lat = locations[locations.size - 1].latitude
                        lng = locations[locations.size - 1].longitude
                        PrefsManager.get().save(PrefsManager.PREF_LOCATION_LATITUDE, lat)
                        PrefsManager.get().save(PrefsManager.PREF_LOCATION_LONGITUDE, lng)
                    }

                }
            }
        }
    }

    companion object {
        private val ACTION_PROCESS_UPDATES = "com.codebrew.vipcartsdriver.utils.location.action" + ".PROCESS_UPDATES"
        private val TAG = LocationUpdatesIntentService::class.java.simpleName
    }
}
