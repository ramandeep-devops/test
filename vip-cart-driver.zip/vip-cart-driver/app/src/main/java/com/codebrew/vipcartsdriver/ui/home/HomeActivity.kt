package com.codebrew.vipcartsdriver.ui.home

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.PendingIntent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import com.codebrew.vipcartsdriver.R
import android.arch.lifecycle.ViewModelProviders
import android.databinding.DataBindingUtil
import android.support.design.widget.Snackbar
import android.widget.Toast
import com.codebrew.vipcartsdriver.model.*
import com.codebrew.vipcartsdriver.utils.*
import com.suru.myp.*
import kotlinx.android.synthetic.main.activity_home.*
import com.codebrew.vipcartsdriver.databinding.ActivityHomeBinding
import android.content.Intent
import android.content.Context
import android.content.DialogInterface
import android.view.Menu
import android.view.MenuItem
import com.codebrew.vipcartsdriver.model.bookingItem.DocumentsItem
import com.codebrew.vipcartsdriver.ui.myAccount.MyAccountFragment
import com.codebrew.vipcartsdriver.utils.PermissionUtils
import com.codebrew.vipcartsdriver.utils.location.LocationUpdatesBroadcastReceiver
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationRequest
import com.google.android.gms.location.LocationServices
import java.io.*
import com.kbeanie.multipicker.api.*
import com.kbeanie.multipicker.api.callbacks.ImagePickerCallback
import com.kbeanie.multipicker.api.entity.ChosenImage
import permissions.dispatcher.*
import java.util.*

@RuntimePermissions
class HomeActivity : AppCompatActivity() {

    companion object {
        fun start(context: Context) {
            context.startActivity(Intent(context, HomeActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP))
        }
    }

    private lateinit var mHomeViewModel: HomeViewModel
    private lateinit var mLoadingDialog: LoadingDialog
    private lateinit var binding: ActivityHomeBinding
    private lateinit var myPicker: MonthYearPicker
    private lateinit var cameraImagePicker: CameraImagePicker
    private lateinit var dateAdapter: DateAdapter
    private lateinit var bookingAdapter: BookingsAdapter
    private val UPDATE_INTERVAL: Long = 10000 // Every 10 seconds.
    private val FASTEST_UPDATE_INTERVAL: Long = 5000// Every 5 seconds
    private val MAX_WAIT_TIME = UPDATE_INTERVAL * 1 // Every 10 sec.
    private var mLocationRequest: LocationRequest? = null
    private var mFusedLocationClient: FusedLocationProviderClient? = null
    private var booking: Booking? = null
    private var bookingList = ArrayList<Booking>()
    private val cal = Calendar.getInstance()


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView<ActivityHomeBinding>(this@HomeActivity,
                R.layout.activity_home)
        init()
        setAdapter()
        setLocationRequest()
        setListeners()
        setVariablesObserver()
        mHomeViewModel.setToolbarData(cal.get(Calendar.MONTH), cal.get(Calendar.YEAR))
    }

    private fun setLocationRequest() {
        mFusedLocationClient = LocationServices.getFusedLocationProviderClient(this)
        createLocationRequest()
        if (PrefsManager.get().getBoolean(PrefsManager.PREF_IS_ANY_TRIP_STARTED, false)) {
            requestLocationUpdates()
        }
    }

    private fun setVariablesObserver() {
        mHomeViewModel.toolbarData.observeForever {
            tvMonthYear.text = it
            setDateObserver()
        }

        mHomeViewModel.dateChange.observeForever {
            if(mHomeViewModel.selectedMonth.get() == cal.get(Calendar.MONTH) &&
                    mHomeViewModel.selectedYear.get() == cal.get(Calendar.YEAR)){
                rvDate.smoothScrollToPosition((mHomeViewModel.selectedDay.get()?:1)-1)
            }
            else{
                rvDate.smoothScrollToPosition(0)
            }
            setBookingObserver()
        }

        mHomeViewModel.displayChild.observeForever {
            it?.let {
                viewFlipper.displayedChild = ch(it)
                if (it == 2) {
                    noData.setMessageWithImage(mHomeViewModel.noTasksLabel.get()?:"",
                            mHomeViewModel.noTaskIconRes.get()?:0)
                }
            }
        }

        mHomeViewModel.locationPermission.observeForever {
            it?.let {
                checkLocationPermissionWithPermissionCheck(it)
            }
        }

        mHomeViewModel.addDoc.observeForever {
            it?.let {
                booking = it
                checkImagePermissionWithPermissionCheck()
            }
        }

        mHomeViewModel.loading.observeForever {
            it?.let {
                mLoadingDialog.setLoading(it)

            }
        }
    }

    @NeedsPermission(Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION)
    fun checkLocationPermission(booking: Booking) {
        bookingStatusChangeObserver(booking)
    }

    @SuppressLint("NoCorrespondingNeedsPermission")
    @OnShowRationale(Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION)
    fun showRationaleForLocation(request: PermissionRequest) {
        PermissionUtils.showRationalDialog(this, R.string.permission_location_deny, request)
    }

    @OnPermissionDenied(Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION)
    fun onLocationDenied() {
        PermissionUtils.showAppSettingsDialog(this, R.string.permission_location_open_settings)
    }

    @OnNeverAskAgain(Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION)
    fun onLocationNeverAskAgain() {
        PermissionUtils.showAppSettingsDialog(this, R.string.permission_location_open_settings)
    }


    @NeedsPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE)
    fun checkImagePermission() {
        cameraImagePicker.pickImage()
    }

    @SuppressLint("NoCorrespondingNeedsPermission")
    @OnShowRationale(Manifest.permission.WRITE_EXTERNAL_STORAGE)
    fun showRationaleForCamera(request: PermissionRequest) {
        PermissionUtils.showRationalDialog(this, R.string.permission_storage_deny, request)
    }

    @OnPermissionDenied(Manifest.permission.WRITE_EXTERNAL_STORAGE)
    fun onCameraDenied() {
        PermissionUtils.showAppSettingsDialog(this, R.string.permission_storage_open_settings)
    }

    @OnNeverAskAgain(Manifest.permission.WRITE_EXTERNAL_STORAGE)
    fun onCameraNeverAskAgain() {
        PermissionUtils.showAppSettingsDialog(this, R.string.permission_storage_open_settings)
    }


    private fun setDateObserver() {
        mHomeViewModel.getDates().observeForever {
            it?.let { it1 -> dateAdapter.setDateList(it1) }
        }
    }

    private fun setBookingObserver() {
        mHomeViewModel.getBookings().observeForever {
            it?.let {
                bookingList = it
                bookingAdapter.setBookingList(it)
            }
        }
    }

    private fun setDocsObserver(id: String, file: File) {
        mHomeViewModel.uploadDoc(id, file).observeForever {
            it?.let {
            }
        }
    }

    private fun bookingStatusChangeObserver(booking: Booking) {
        mHomeViewModel.onBookingStatusChange(booking).observeForever {
            it?.let {
                bookingAdapter.notifyItemChanged(bookingList.indexOf(booking))
                if (booking.status == AppConstants.STATUS_STARTED) {
                    PrefsManager.get().save(PrefsManager.PREF_IS_ANY_TRIP_STARTED, true)
                    PrefsManager.get().save(PrefsManager.PREF_BOOKING_ID, ch(it.bookingId))
                    if (booking.serviceTypeActual != AppConstants.SELECTED_CAR_SERVICE) {
                        requestLocationUpdates()
                    }
                }
                else if (booking.status == AppConstants.STATUS_DELIVERED) {
                    PrefsManager.get().save(PrefsManager.PREF_IS_ANY_TRIP_STARTED, false)
                    if (booking.serviceTypeActual != AppConstants.SELECTED_CAR_SERVICE) {
                        removeLocationUpdates()
                    }
                }
            }
        }
    }

    private fun init() {
        val factory = HomeViewModel.Factory(
                application, HomeRepository.getInstance())
        mHomeViewModel = ViewModelProviders.of(
                this, factory).get(HomeViewModel::class.java)
        mLoadingDialog = LoadingDialog(this)

        mHomeViewModel.let {
            binding.root.setupSnackbar(this,
                    it.snackbarMessage, Snackbar.LENGTH_SHORT)
        }
        myPicker = MonthYearPicker(this)
        myPicker.build(
                DialogInterface.OnClickListener { _, _ ->
                    mHomeViewModel.setToolbarData(myPicker.selectedMonth,
                            myPicker.selectedYear)
                }, null)
        cameraImagePicker = CameraImagePicker(this)
        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayShowTitleEnabled(false)

    }

    private fun setAdapter() {
        dateAdapter = DateAdapter(mHomeViewModel)
        bookingAdapter = BookingsAdapter(mHomeViewModel)
        rvDate.adapter = dateAdapter
        rvBookings.adapter = bookingAdapter
    }

    private fun setListeners() {
        tvMonthYear.setOnClickListener {
            myPicker.show()
        }

        cameraImagePicker.setImagePickerCallback(object : ImagePickerCallback {
            override fun onImagesChosen(images: List<ChosenImage>) {
                setDocsObserver(ch(booking?.bookingId), File(images[0].originalPath))
                val document = DocumentsItem(original = images[0].originalPath, thumbnail = images[0].originalPath)
                booking?.listImages?.add(document)
                bookingAdapter.notifyItemChanged(bookingList.indexOf(booking))
            }

            override fun onError(message: String) {
                Toast.makeText(this@HomeActivity, message, Toast.LENGTH_SHORT).show()
            }
        })


    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == Activity.RESULT_OK) {
            when (requestCode) {
                Picker.PICK_IMAGE_CAMERA -> cameraImagePicker.submit(data)
            }
        }
    }

    private fun createLocationRequest() {
        mLocationRequest = LocationRequest()
        mLocationRequest?.interval = UPDATE_INTERVAL
        mLocationRequest?.fastestInterval = FASTEST_UPDATE_INTERVAL
        mLocationRequest?.priority = LocationRequest.PRIORITY_HIGH_ACCURACY
        mLocationRequest?.maxWaitTime = MAX_WAIT_TIME
    }

    private fun getPendingIntent(): PendingIntent {
        val intent = Intent(this, LocationUpdatesBroadcastReceiver::class.java)
        intent.action = LocationUpdatesBroadcastReceiver.ACTION_PROCESS_UPDATES
        return PendingIntent.getBroadcast(this, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT)
    }

    private fun requestLocationUpdates() {
        try {
            PrefsManager.get().save(PrefsManager.PREF_LOCATION_REQUESTING, true)
            mFusedLocationClient?.requestLocationUpdates(mLocationRequest, getPendingIntent())
        } catch (e: SecurityException) {
            PrefsManager.get().save(PrefsManager.PREF_LOCATION_REQUESTING, false)
            e.printStackTrace()
        }

    }

    private fun removeLocationUpdates() {
        PrefsManager.get().save(PrefsManager.PREF_LOCATION_REQUESTING, false)
        mFusedLocationClient?.removeLocationUpdates(getPendingIntent())
    }

    @SuppressLint("NeedOnRequestPermissionsResult")
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        onRequestPermissionsResult(requestCode, grantResults)
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        val inflater = menuInflater
        inflater.inflate(R.menu.main, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem?): Boolean {
        return if (item?.itemId == R.id.actionProfile) {
            supportFragmentManager.beginTransaction().
                    add(android.R.id.content, MyAccountFragment(),
                            MyAccountFragment::class.java.name).addToBackStack(null).commitAllowingStateLoss()
            true
        } else {
            super.onOptionsItemSelected(item)
        }
    }

}