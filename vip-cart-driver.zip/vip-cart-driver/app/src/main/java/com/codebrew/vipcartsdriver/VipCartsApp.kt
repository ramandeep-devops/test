package com.codebrew.vipcartsdriver

import android.app.Application
import com.codebrew.vipcartsdriver.utils.PrefsManager


class VipCartsApp : Application()
{
    override fun onCreate()
    {
        super.onCreate()
        PrefsManager.initialize(this)
        //ZopimChat.init(ApiConstants.ZENDESK_KEY)
    }
}