package com.codebrew.vipcartsdriver.ui.home

import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.bumptech.glide.Glide
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.bumptech.glide.load.resource.bitmap.RoundedCorners
import com.bumptech.glide.request.RequestOptions
import com.codebrew.vipcartsdriver.R
import com.codebrew.vipcartsdriver.databinding.ItemDocumentBinding
import com.codebrew.vipcartsdriver.model.Booking
import com.codebrew.vipcartsdriver.model.bookingItem.DocumentsItem
import com.codebrew.vipcartsdriver.utils.ch
import kotlinx.android.synthetic.main.item_document.view.*


class AddDocAdapter(private val homeViewModel: HomeViewModel,
                    private val booking: Booking
) : RecyclerView.Adapter<AddDocAdapter.ViewHolder>() {

    private var imageList = booking.listImages
    private lateinit var binding: ItemDocumentBinding

    override fun onCreateViewHolder(parent: ViewGroup?, viewType: Int): ViewHolder {
        binding = ItemDocumentBinding.inflate(LayoutInflater.from(parent?.context),
                parent,
                false)
        return ViewHolder(binding.root, homeViewModel, booking)
    }

    override fun getItemCount(): Int = imageList.size + 1


    override fun onBindViewHolder(holder: ViewHolder?, position: Int) {
        if (position == 0) {
            holder?.bind()
        } else {
            holder?.bind(imageList[position - 1])
        }
    }

    inner class ViewHolder(private val view: View, homeViewModel: HomeViewModel, booking: Booking) : RecyclerView.ViewHolder(view) {
        init {
            view.setOnClickListener {
                if (adapterPosition == 0) {
                    homeViewModel.onAddDoc(booking)
                }
            }
        }

        fun bind(imageDoc: DocumentsItem?) {
            val image = ch(imageDoc?.thumbnail)
            val options = RequestOptions()
                    .transform(RoundedCorners(8))
                    .diskCacheStrategy(DiskCacheStrategy.DATA)
            if (image.contains(".pdf") || image.contains(".doc") || image.contains("docx")) {
                Glide.with(view.context)
                        .load(R.mipmap.ic_doc)
                        .apply(options)
                        .into(view.ivDocument)
            } else {
                Glide.with(view.context)
                        .load(image)
                        .apply(options)
                        .into(view.ivDocument)
            }
        }

        fun bind() {
            Glide.with(view.context)
                    .load(R.drawable.ic_camera)
                    .into(view.ivDocument)
        }

    }

    fun setDateList(imageList: ArrayList<DocumentsItem?>) {
        this.imageList.clear()
        this.imageList.addAll(imageList)
        notifyDataSetChanged()
    }

}