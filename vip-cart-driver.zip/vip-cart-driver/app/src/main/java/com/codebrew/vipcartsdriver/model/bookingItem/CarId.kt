package com.codebrew.vipcartsdriver.model.bookingItem

import com.google.gson.annotations.SerializedName

data class CarId(

	@field:SerializedName("carNameAr")
	val carNameAr: String? = null,

	@field:SerializedName("carName")
	val carName: String? = null,

	@field:SerializedName("imageUrl")
	val imageUrl: List<ImageUrlItem?>? = null,

	@field:SerializedName("_id")
	val id: String? = null,

	@field:SerializedName("serviceId")
	val serviceId: ServiceId? = null
)