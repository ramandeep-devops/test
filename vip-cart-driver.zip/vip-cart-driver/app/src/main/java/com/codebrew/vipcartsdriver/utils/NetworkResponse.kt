package com.codebrew.vipcartsdriver.utils


class NetworkResponse<out T>(val status: Int, val data: T?, val errorMessage: String?) {
    companion object {

        val SUCCESS = 1
        val FAILURE = 0
        val LOADING = 2
        val BAD_REQUEST = 3
        val NO_NETWORK = 4
        val UNAUTHORISED = 5
        val EMPTY = 6

        fun <T> noNetwork(data: T?, errorMessage: String): NetworkResponse<T>? {
            return NetworkResponse(NO_NETWORK, data, errorMessage)
        }

        fun <T> success(data: T?): NetworkResponse<T>? {
            return NetworkResponse(SUCCESS, data, null)
        }

        fun <T> error(data: T?, errorMessage: String): NetworkResponse<T>? {
            return NetworkResponse(FAILURE, data, errorMessage)
        }

        fun <T> badRequest(data: T?, errorMessage: String): NetworkResponse<T>? {
            return NetworkResponse(BAD_REQUEST, data, errorMessage)
        }

        fun <T> unAuthorised(data: T?): NetworkResponse<T>? {
            return NetworkResponse(UNAUTHORISED, data, null)
        }

        fun <T> loading(data: T?): NetworkResponse<T>? {
            return NetworkResponse(LOADING, data, null)
        }

        fun <T> empty(data: T?): NetworkResponse<T>? {
            return NetworkResponse(EMPTY, data, null)
        }
    }
}