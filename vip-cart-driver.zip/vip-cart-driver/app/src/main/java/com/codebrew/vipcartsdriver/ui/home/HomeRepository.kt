package com.codebrew.vipcartsdriver.ui.home

import android.arch.lifecycle.MutableLiveData
import com.codebrew.vipcartsdriver.R
import com.codebrew.vipcartsdriver.model.*
import com.codebrew.vipcartsdriver.model.bookingItem.DocumentsItem
import com.codebrew.vipcartsdriver.model.bookingItem.ResponseBooking
import com.codebrew.vipcartsdriver.network.RetrofitClient
import com.codebrew.vipcartsdriver.utils.AppConstants
import com.codebrew.vipcartsdriver.utils.NetworkResponse
import com.codebrew.vipcartsdriver.utils.PrefsManager
import com.codebrew.vipcartsdriver.utils.ch
import okhttp3.MediaType
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.io.File
import java.text.SimpleDateFormat
import java.util.*
import kotlin.collections.ArrayList
import okhttp3.RequestBody
import okhttp3.MultipartBody


class HomeRepository {

    fun getDates(month: Int, year: Int): MutableLiveData<NetworkResponse<*>> {
        val data = MutableLiveData<NetworkResponse<*>>()

        val calendar = Calendar.getInstance()
        val calendarActual = Calendar.getInstance()
        calendar.set(Calendar.MONTH, month)
        calendar.set(Calendar.YEAR, year)
        calendar.set(Calendar.DAY_OF_MONTH, 1)
        val days = calendar.getActualMaximum(Calendar.DAY_OF_MONTH)
        val list = ArrayList<DateItem>()
        (1..days).forEach {
            if (calendarActual.get(Calendar.MONTH) == month &&
                    calendarActual.get(Calendar.YEAR) == year) {
                val date = DateItem(days, (it).toString(), getDayName(it, month, year), (it) == calendarActual.get(Calendar.DAY_OF_MONTH))
                list.add(date)
            } else {
                val date = DateItem(days, (it).toString(), getDayName(it, month, year), (it) == 1)
                list.add(date)
            }

        }
        data.value = NetworkResponse(NetworkResponse.SUCCESS, list, null)
        return data
    }

    fun toolbarDate(month: Int, year: Int): String {
        var monthYear = ""
        val calendar = Calendar.getInstance()
        calendar.set(Calendar.MONTH, month)
        calendar.set(Calendar.YEAR, year)
        calendar.set(Calendar.DAY_OF_MONTH, 1)
        val simpleDateFormat = SimpleDateFormat("MMMM yyyy", Locale.ENGLISH)
        try {
            monthYear = simpleDateFormat.format(calendar.time)
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return monthYear
    }

    private fun getDayName(day: Int, month: Int, year: Int): String {
        var dayName = ""
        val calendar = Calendar.getInstance()
        calendar.set(Calendar.DAY_OF_MONTH, day)
        calendar.set(Calendar.MONTH, month)
        calendar.set(Calendar.YEAR, year)
        val simpleDateFormat = SimpleDateFormat("EEE", Locale.ENGLISH)
        try {
            dayName = simpleDateFormat.format(calendar.time)
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return dayName
    }

    fun bookingDate(day: Int, month: Int, year: Int): String {
        var date = ""
        val calendar = Calendar.getInstance()
        calendar.set(Calendar.MONTH, month)
        calendar.set(Calendar.YEAR, year)
        calendar.set(Calendar.DAY_OF_MONTH, day)
        val simpleDateFormat = SimpleDateFormat("MM/dd/yyyy", Locale.ENGLISH)
        try {
            date = simpleDateFormat.format(calendar.time)
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return date
    }

    fun uploadDoc(bookingId: String, file: File): MutableLiveData<NetworkResponse<*>> {
        val data = MutableLiveData<NetworkResponse<*>>()
        val fileAsRequestBody = RequestBody.create(MediaType.parse("image/*"), file)
        val body = MultipartBody.Part.createFormData("image", file.name, fileAsRequestBody)
        val bookingIdRb = RequestBody.create(MediaType.parse("text/plain"), bookingId)

        RetrofitClient.getApi().uploadDocs(PrefsManager.get().getString(PrefsManager.PREF_API_TOKEN, "")
                , bookingIdRb, body).enqueue(object : Callback<ApiResponse<ArrayList<DocumentsItem>>> {
            override fun onFailure(call: Call<ApiResponse<ArrayList<DocumentsItem>>>?, t: Throwable?) {
                data.value = NetworkResponse(NetworkResponse.FAILURE, null, "Error")
            }

            override fun onResponse(call: Call<ApiResponse<ArrayList<DocumentsItem>>>?,
                                    response: Response<ApiResponse<ArrayList<DocumentsItem>>>?) {
                if (response?.isSuccessful == true) {
                    val dataList = response.body()?.getData()
                    if (dataList != null && dataList.size > 0) {
                        data.value = NetworkResponse(NetworkResponse.SUCCESS,
                                response.body()?.getData(), "")
                    } else {
                        data.value = NetworkResponse(NetworkResponse.EMPTY, response.body()?.getData(), "")
                    }
                } else {
                    data.value = NetworkResponse(NetworkResponse.FAILURE, null, "Error")
                }
            }


        })

        return data
    }

    fun getBookings(date: String): MutableLiveData<NetworkResponse<*>> {
        val data = MutableLiveData<NetworkResponse<*>>()

        RetrofitClient.getApi().getBookings(PrefsManager.get().getString(PrefsManager.PREF_API_TOKEN, "")
                , date).enqueue(object : Callback<ApiResponse<ArrayList<ResponseBooking>>> {
            override fun onFailure(call: Call<ApiResponse<ArrayList<ResponseBooking>>>?, t: Throwable?) {
                data.value = NetworkResponse(NetworkResponse.FAILURE, null, "Error")
            }

            override fun onResponse(call: Call<ApiResponse<ArrayList<ResponseBooking>>>?,
                                    response: Response<ApiResponse<ArrayList<ResponseBooking>>>?) {
                if (response?.isSuccessful == true) {
                    val dataList = response.body()?.getData()
                    if (dataList != null && dataList.size > 0) {
                        data.value = NetworkResponse(NetworkResponse.SUCCESS, getFormattedData(response.body()?.getData()), "")
                    } else {
                        data.value = NetworkResponse(NetworkResponse.EMPTY, getFormattedData(response.body()?.getData()), "")
                    }
                } else
                    data.value = NetworkResponse(NetworkResponse.FAILURE, null, "Error")
            }


        })

        return data
    }


    fun bookingStatusChange(booking: Booking, status: Int): MutableLiveData<NetworkResponse<*>> {
        val data = MutableLiveData<NetworkResponse<*>>()

        RetrofitClient.getApi().changeTripStatus(PrefsManager.get().getString(PrefsManager.PREF_API_TOKEN, "")
                , ch(booking.bookingId), status).enqueue(object : Callback<ApiResponse<Any>> {

            override fun onFailure(call: Call<ApiResponse<Any>>?, t: Throwable?) {
                data.value = NetworkResponse(NetworkResponse.FAILURE, null, "Error")
            }

            override fun onResponse(call: Call<ApiResponse<Any>>?,
                                    response: Response<ApiResponse<Any>>?) {
                if (response?.isSuccessful == true) {
                    data.value = NetworkResponse(NetworkResponse.SUCCESS, getChangedBooking(booking, status), "")
                } else
                    data.value = NetworkResponse(NetworkResponse.FAILURE, null, "Error")
            }
        })

        return data
    }




    private fun getChangedBooking(booking: Booking, status: Int): Booking {
        when (status) {
            1 -> booking.status = AppConstants.STATUS_STARTED
            3 -> booking.status = AppConstants.STATUS_DELIVERED_TO_USER
            else -> booking.status = AppConstants.STATUS_DELIVERED
        }
        booking.statusFormatted = ch(getBookingStatus(booking.status))
        booking.statusChange = ch(getChangedBookingStatus(booking.status,
                booking.serviceTypeActual))
        return booking
    }

    private fun getFormattedData(data: ArrayList<ResponseBooking>?): ArrayList<Booking>? {
        val dataFormatted = ArrayList<Booking>()
        data?.forEach {
            dataFormatted.add(getBooking(it))
        }
        return dataFormatted
    }

    private fun getBooking(bookingItem: ResponseBooking): Booking {
        return Booking(pickupTime = getTime(bookingItem.pickUpDate),
                dropOffTme = getTime(bookingItem.dropOffDate),
                pickupAddress = bookingItem.pickUpAddress,
                dropOffAddress = bookingItem.dropOffAddress,
                name = bookingItem.userId?.firstName + " " + bookingItem.userId?.lastName,
                bookingId = bookingItem.id,
                listImages = ch(bookingItem.documents),
                contact = ch(bookingItem.userId?.countryCode + bookingItem.userId?.phoneNumber),
                latlng = ch(bookingItem.userId?.location),
                status = ch(bookingItem.status),
                statusFormatted = ch(getBookingStatus(bookingItem.status)),
                serviceTypeActual = ch(bookingItem.carId?.serviceId?.code),
                statusChange = ch(getChangedBookingStatus(bookingItem.status, bookingItem.carId?.serviceId?.code)),
                serviceType = ch(getServiceType(bookingItem.carId?.serviceId?.code))
        )
    }

    private fun getServiceType(code: Int?): Int? {
        return when (code) {
            AppConstants.SELECTED_CAR_SERVICE -> {
                (R.string.service_car_rent)
            }
            AppConstants.SELECTED_CHAUFFEUR_SERVICE -> {
                (R.string.service_chauffer)
            }
            else -> {
                (R.string.service_limo)
            }
        }
    }

    private fun getBookingStatus(status: String?): Int? {
        return when (status) {
            AppConstants.STATUS_PENDING -> {
                (R.string.service_pending)
            }
            AppConstants.STATUS_CONFIRMED -> {
                (R.string.service_confirmed)
            }
            AppConstants.STATUS_CANCELLED -> {
                (R.string.service_cancelled)
            }
            AppConstants.STATUS_STARTED -> {
                (R.string.service_started)
            }
            else -> {
                (R.string.service_completed)
            }
        }
    }

    private fun getChangedBookingStatus(status: String?, code: Int?): Int? {
        return when (status) {
            AppConstants.STATUS_PENDING, AppConstants.STATUS_CONFIRMED -> {
                (R.string.service_on_the_way)

                /* if (code == AppConstants.SELECTED_CAR_SERVICE) {
                     (R.string.service_deliver_car)
                 } else {
                     (R.string.service_start_trip)
                 }*/
            }
            AppConstants.STATUS_DELIVERED_TO_USER -> {
                (R.string.service_delivered_car)
            }
            AppConstants.STATUS_STARTED -> {
                 if (code == AppConstants.SELECTED_CAR_SERVICE) {
                    (R.string.service_deliver_car)
                } else {
                     (R.string.service_end_trip)
                 }
               // (R.string.service_end_trip)
            }
            else -> {
                (R.string.service_completed_trip)
            }
        }
    }

    private fun getTime(time: Long?): String {
        var dayTime = ""
        val simpleDateFormat = SimpleDateFormat("MMM dd'\n'hh:mm a", Locale.ENGLISH)
        try {
            dayTime = simpleDateFormat.format(time)
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return dayTime
    }


    companion object {

        private var INSTANCE: HomeRepository? = null

        @JvmStatic
        fun getInstance() =
                INSTANCE ?: synchronized(HomeRepository::class.java) {
                    INSTANCE ?: HomeRepository()
                            .also { INSTANCE = it }
                }

        @JvmStatic
        fun destroyInstance() {
            INSTANCE = null
        }
    }
}