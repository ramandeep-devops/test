package com.codebrew.vipcartsdriver.model

data class DateItem( var count: Int = 0,
         val date: String,
         val dayName: String,
         var isSelected: Boolean = false)