package com.codebrew.vipcartsdriver.ui.myAccount

import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.bumptech.glide.Glide
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.bumptech.glide.load.resource.bitmap.CircleCrop
import com.bumptech.glide.request.RequestOptions
import com.codebrew.vipcartsdriver.R
import com.codebrew.vipcartsdriver.databinding.ItemDocumentBinding
import com.codebrew.vipcartsdriver.model.bookingItem.DocumentsItem
import com.codebrew.vipcartsdriver.utils.ch
import kotlinx.android.synthetic.main.item_document.view.*


class DocsAdapter(listImages: ArrayList<DocumentsItem?>
) : RecyclerView.Adapter<DocsAdapter.ViewHolder>() {

    private var imageList = listImages
    private lateinit var binding: ItemDocumentBinding
    override fun onCreateViewHolder(parent: ViewGroup?, viewType: Int): ViewHolder {
        binding = ItemDocumentBinding.inflate(LayoutInflater.from(parent?.context),
                parent,
                false)
        return ViewHolder(binding.root)
    }

    override fun getItemCount(): Int = imageList.size

    override fun onBindViewHolder(holder: ViewHolder?, position: Int) {
        holder?.bind(imageList[position])
    }

    inner class ViewHolder(private val view: View) : RecyclerView.ViewHolder(view) {
        private lateinit var image: String

        init {

        }

        fun bind(imageDoc: DocumentsItem?) {
            this.image = ch(imageDoc?.thumbnail)
            val options = RequestOptions()
                    .transform(CircleCrop())
                    .diskCacheStrategy(DiskCacheStrategy.DATA)
            if (image.contains(".pdf") || image.contains(".doc") || image.contains("docx")) {
                Glide.with(view.context)
                        .load(R.mipmap.ic_doc)
                        .apply(options)
                        .into(view.ivDocument)
            } else {
                Glide.with(view.context)
                        .load(image)
                        .apply(options)
                        .into(view.ivDocument)
            }
        }

    }

}