package com.codebrew.vipcartsdriver.utils

object ApiConstants
{
    //const val BASE_PATH = "http://192.168.100.88:8000/userapi/"
    //const val BASE_PATH = "http://34.211.8.244/userapi/"
    const val BASE_PATH = "https://vipcartapi.netsolutionindia.com/driver/"
    //const val ZENDESK_KEY = "5OqIOIjKAtjON4ssy2PHSyVGsBpzosE0"

    const val ENDPOINT_LOGIN = "login"
    const val ENDPOINT_GET_BOOKINGS = "getBookings"
    const val ENDPOINT_UPLOAD_DOCS = "uploadDocs"
    const val ENDPOINT_TRACKING = "addLocation"
    const val ENDPOINT_NOTIFICATION = "getNotification"
    const val ENDPOINT_STATUS_CHANGE = "changeStatus"


    const val PARAM_AUTHORIZATION = "authorization"
    const val PARAM_DATE = "date"
    const val PARAM_BOOKING_ID= "bookingId"
    const val PARAM_LATITUDE= "lat"
    const val PARAM_LONGITUDE= "long"
    const val PARAM_STATUS= "status"

}