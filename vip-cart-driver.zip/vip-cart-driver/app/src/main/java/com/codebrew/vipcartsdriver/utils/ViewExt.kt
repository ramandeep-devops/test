
package com.codebrew.vipcartsdriver.utils

import android.arch.lifecycle.LifecycleOwner
import android.arch.lifecycle.Observer
import android.support.design.widget.Snackbar
import android.view.View
import java.util.*
import kotlin.collections.ArrayList

/**
 * Transforms static java function Snackbar.make() to an extension function on View.
 */
fun View.showSnackbar(snackbarText: String, timeLength: Int) {
    Snackbar.make(this, snackbarText, timeLength).show()
}

/**
 * Triggers a snackbar message when the value contained by snackbarTaskMessageLiveEvent is modified.
 */
fun View.setupSnackbar(lifecycleOwner: LifecycleOwner,
                       snackbarMessageLiveEvent: SingleLiveEvent<Int>, timeLength: Int) {
    snackbarMessageLiveEvent.observe(lifecycleOwner, Observer {
        it?.let { showSnackbar(context.getString(it), timeLength) }
    })
}

fun sumNumbers(vararg numbers: Float): Float {
    return numbers.sum()
}



inline fun <reified T> ch(item: T?): T {
    return when (item) {
        is String? -> {
            item ?: "" as T
        }
        is Int? -> {
            item ?: 0 as T
        }
        is Double? -> {
            item ?: 0.00 as T
        }
        is Boolean? ->{
            item?: false as T
        }
        is Float? ->{
            item ?: 0.00 as T
        }
        is ArrayList<*>? -> {
            item ?: ArrayList<T>() as T
        }
        else->{
            item ?: item as T
        }
    }
}










