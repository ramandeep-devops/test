package com.codebrew.vipcartsdriver.utils

import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.support.annotation.StringRes
import com.codebrew.vipcartsdriver.R
import permissions.dispatcher.PermissionRequest

object PermissionUtils
{
    fun showRationalDialog(context: Context?, @StringRes messageResId: Int, request: PermissionRequest)
    {
        context?.let {
            AlertDialog.Builder(context)
                    .setPositiveButton(R.string.permission_btn_allow, { _, _ -> request.proceed() })
                    .setNegativeButton(R.string.permission_btn_deny, { _, _ -> request.cancel() })
                    .setCancelable(false)
                    .setMessage(messageResId)
                    .show()
        }
    }

    fun showAppSettingsDialog(context: Context?, @StringRes messageResId: Int) {
        context?.let {
            AlertDialog.Builder(context)
                    .setPositiveButton(R.string.permission_btn_settings, { _, _ ->
                        val intent = Intent()
                        intent.action = Settings.ACTION_APPLICATION_DETAILS_SETTINGS
                        intent.data = Uri.fromParts("package", context.packageName, null)
                        context.startActivity(intent)
                    })
                    .setNegativeButton(android.R.string.cancel, { dialog, _ -> dialog.dismiss() })
                    .setCancelable(false)
                    .setMessage(messageResId)
                    .show()
        }
    }
}