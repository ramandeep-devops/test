package com.codebrew.vipcartsdriver.ui.home

import android.app.Application
import android.arch.lifecycle.*
import android.databinding.ObservableBoolean
import android.databinding.ObservableField
import android.graphics.drawable.Drawable
import android.support.annotation.StringRes
import android.arch.core.util.Function
import com.codebrew.vipcartsdriver.model.Booking
import com.codebrew.vipcartsdriver.R
import com.codebrew.vipcartsdriver.model.DateItem
import com.codebrew.vipcartsdriver.model.bookingItem.DocumentsItem
import com.codebrew.vipcartsdriver.utils.AppConstants
import com.codebrew.vipcartsdriver.utils.NetworkResponse
import com.codebrew.vipcartsdriver.utils.SingleLiveEvent
import com.codebrew.vipcartsdriver.utils.ch
import java.io.File
import java.util.*


class HomeViewModel(private val context: Application,
                    private val homeRepository: HomeRepository) :
        AndroidViewModel(context) {

    private lateinit var networkResponseMutableLiveData: MutableLiveData<NetworkResponse<*>>
    private var bookingsMediatorLiveData = MediatorLiveData<ArrayList<Booking>>()
    private var datesMediatorLiveData = MediatorLiveData<ArrayList<DateItem>>()
    private var docsMediatorLiveData = MediatorLiveData<ArrayList<DocumentsItem>>()
    private val statusChangeLiveData = MediatorLiveData<Booking>()
    val snackbarMessage = SingleLiveEvent<Int>()
    val noTasksLabel = ObservableField<String>()
    val noTaskIconRes = ObservableField<Int>()
    val toolbarData = SingleLiveEvent<String>()
    val selectedMonth = ObservableField<Int>()
    val selectedYear = ObservableField<Int>()
    val selectedDay = ObservableField<Int>()
    val displayChild = SingleLiveEvent<Int>()
    val dateChange = SingleLiveEvent<String>()
    val addDoc = SingleLiveEvent<Booking>()
    val locationPermission = SingleLiveEvent<Booking>()
    val loading = SingleLiveEvent<Boolean>()


    fun setToolbarData(month: Int, year: Int) {
        selectedMonth.set(month)
        selectedYear.set(year)
        val calendar = Calendar.getInstance()
        if (calendar.get(Calendar.MONTH) == month) {
            selectedDay.set(calendar.get(Calendar.DAY_OF_MONTH))
        } else {
            selectedDay.set(1)
        }
        toolbarData.value = (homeRepository.toolbarDate(month, year))
        dateChange.value = homeRepository.bookingDate(selectedDay.get()?:0,
                selectedMonth.get()?:0, selectedYear.get()?:0)
    }

    fun getBookings(): LiveData<ArrayList<Booking>> {
        displayChild.value = 0
        networkResponseMutableLiveData = homeRepository.getBookings(ch(dateChange.value))
        return Transformations.switchMap(networkResponseMutableLiveData,
                Function<NetworkResponse<*>, LiveData<ArrayList<Booking>>>() {
                    if (it?.status == NetworkResponse.SUCCESS) {
                        if (it.data != null) {
                            displayChild.value = 1
                            bookingsMediatorLiveData.value = (it.data as ArrayList<Booking>?)
                        } else {
                            setDataForError(true)
                            displayChild.value = 2
                        }
                    } else if (it?.status == NetworkResponse.FAILURE) {
                        setDataForError(true)
                        displayChild.value = 2
                    } else if (it?.status == NetworkResponse.EMPTY) {
                        setDataForError(false)
                        displayChild.value = 2
                    }
                    return@Function bookingsMediatorLiveData
                })

    }

    fun getDates(): LiveData<ArrayList<DateItem>> {
        networkResponseMutableLiveData = homeRepository.getDates(selectedMonth.get()?:0,
                selectedYear.get()?:0)
        return Transformations.switchMap(networkResponseMutableLiveData,
                Function<NetworkResponse<*>, LiveData<ArrayList<DateItem>>>() {
                    if (it?.status == NetworkResponse.SUCCESS) {
                        if (it.data != null) {
                            datesMediatorLiveData.value = (it.data as ArrayList<DateItem>?)
                        }
                    }
                    return@Function datesMediatorLiveData
                })

    }

    fun onDateChange(date: String) {
        selectedDay.set(date.toInt())
        dateChange.value = homeRepository.bookingDate(selectedDay.get()?:0,
                selectedMonth.get()?:0, selectedYear.get()?:0)
    }

    private fun setDataForError(isError: Boolean) {
        with(context) {
            if (isError) {
                noTasksLabel.set(getString(R.string.api_error))
                noTaskIconRes.set(R.drawable.img_no_internet)
            } else {
                noTasksLabel.set(getString(R.string.no_bookings))
                noTaskIconRes.set(R.drawable.img_no_data)
            }
        }
    }

    private fun showSnackbarMessage(@StringRes message: Int) {
        snackbarMessage.value = message
    }

    fun onBookingStatusChange(booking: Booking): LiveData<Booking> {
        loading.value = true
        val status: Int = if (booking.status == AppConstants.STATUS_CONFIRMED ||
                booking.status == AppConstants.STATUS_PENDING) {
            1
        } else if (booking.status == AppConstants.STATUS_STARTED) {
            if (booking.serviceTypeActual == AppConstants.SELECTED_CAR_SERVICE) {
                3
            } else {
                2
            }
        }
        else{
            2
        }
        networkResponseMutableLiveData = homeRepository.bookingStatusChange(booking, status)
        return Transformations.switchMap(networkResponseMutableLiveData,
                Function<NetworkResponse<*>, LiveData<Booking>>() {
                    when {
                        it?.status == NetworkResponse.SUCCESS -> {
                            loading.value = false
                            statusChangeLiveData.value = it.data as Booking
                        }
                        it?.status == NetworkResponse.FAILURE -> loading.value = false
                        it?.status == NetworkResponse.EMPTY -> loading.value = false
                    }
                    return@Function statusChangeLiveData
                })
    }

    fun onAddDoc(booking: Booking?) {
        addDoc.value = booking
    }

    fun getLocationPermission(booking: Booking?) {
        locationPermission.value = booking
    }

    fun uploadDoc(id: String, file: File): LiveData<ArrayList<DocumentsItem>> {
        networkResponseMutableLiveData = homeRepository.uploadDoc(id, file)
        return Transformations.switchMap(networkResponseMutableLiveData,
                Function<NetworkResponse<*>, LiveData<ArrayList<DocumentsItem>>>() {
                    if (it?.status == NetworkResponse.SUCCESS) {
                        if (it.data != null) {
                            docsMediatorLiveData.value = (it.data as ArrayList<DocumentsItem>?)
                        } else {
                            showSnackbarMessage(R.string.api_error)
                        }
                    } else if (it?.status == NetworkResponse.FAILURE) {
                        showSnackbarMessage(R.string.api_error)

                    } else if (it?.status == NetworkResponse.EMPTY) {
                        showSnackbarMessage(R.string.api_error)
                    }
                    return@Function docsMediatorLiveData
                })
    }


    class Factory(private val application: Application,
                  private val homeRepository: HomeRepository) :
            ViewModelProvider.NewInstanceFactory() {

        override fun <T : ViewModel> create(modelClass: Class<T>): T {

            return HomeViewModel(application, homeRepository) as T
        }
    }

}