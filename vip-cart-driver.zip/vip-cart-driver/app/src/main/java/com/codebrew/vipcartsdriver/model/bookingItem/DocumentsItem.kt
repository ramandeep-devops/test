package com.codebrew.vipcartsdriver.model.bookingItem

import com.google.gson.annotations.SerializedName

data class DocumentsItem(

	@field:SerializedName("thumbnail")
	val thumbnail: String? = null,

	@field:SerializedName("original")
	val original: String? = null,

	@field:SerializedName("_id")
	val id: String? = null
)