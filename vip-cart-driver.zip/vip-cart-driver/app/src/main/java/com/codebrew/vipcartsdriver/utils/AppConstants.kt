package com.codebrew.vipcartsdriver.utils

object AppConstants
{
    //fonts constants
    const val FONT_COMPTON_BOOK = "fonts/book.ttf"
    const val FONT_COMPTON_BOLD = "fonts/bold.ttf"
    const val FONT_COMPTON_LIGHT = "fonts/light.ttf"
    const val FONT_COMPTON_MEDIUM = "fonts/medium.ttf"

    //service selected
    const val SELECTED_CAR_SERVICE = 1
    const val SELECTED_CHAUFFEUR_SERVICE = 2
    const val SELECTED_LIMO_SERVICE = 3
    const val SELECTED_NUMBER_PLATE_SERVICE = 4

    //device type
    const val TYPE_DEVICE = "ANDROID"

    //booking status
    const val STATUS_PENDING = "PENDING"
    const val STATUS_CONFIRMED = "CONFIRMED"
    const val STATUS_CANCELLED = "CANCELLED"
    const val STATUS_DELIVERED = "DELIVERED"
    const val STATUS_STARTED = "ONTRIP"
    const val STATUS_DELIVERED_TO_USER = "DELIVERTOUSER"

    //
    const val IE_BOOKING_ID = "IE_BOOKING_ID"


}