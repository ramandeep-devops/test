package com.codebrew.vipcartsdriver.ui.home


interface DateItemSelectedListener {
    fun onDateSelected(day: String)
}