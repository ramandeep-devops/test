package com.codebrew.vipcartsdriver.model

class ApiResponse<out T>
{
    private val statusCode: Int? = null
    private val message: String? = null
    private val data: T? = null

    fun getSuccess(): Int? = statusCode

    fun getMessage(): String? = message

    fun getData(): T? = data
}