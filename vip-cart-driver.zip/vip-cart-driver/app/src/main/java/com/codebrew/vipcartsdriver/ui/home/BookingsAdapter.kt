package com.codebrew.vipcartsdriver.ui.home

import android.support.v7.widget.LinearLayoutCompat
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.telephony.PhoneNumberUtils
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.codebrew.vipcartsdriver.R
import com.codebrew.vipcartsdriver.databinding.ItemBookingBinding
import com.codebrew.vipcartsdriver.model.Booking
import com.codebrew.vipcartsdriver.model.bookingItem.DocumentsItem
import com.codebrew.vipcartsdriver.utils.*
import com.kbeanie.multipicker.utils.IntentUtils
import kotlinx.android.synthetic.main.item_booking.view.*

class BookingsAdapter(private val homeViewModel: HomeViewModel
) : RecyclerView.Adapter<BookingsAdapter.ViewHolder>() {

    private var bookingsList = ArrayList<Booking>()
    private lateinit var binding: ItemBookingBinding
    override fun onCreateViewHolder(parent: ViewGroup?, viewType: Int): ViewHolder {
        binding = ItemBookingBinding.inflate(LayoutInflater.from(parent?.context), parent,
                false)
        return ViewHolder(binding.root, homeViewModel, binding)
    }

    override fun getItemCount(): Int = bookingsList.size

    override fun onBindViewHolder(holder: ViewHolder?, position: Int) {
        holder?.bind(bookingsList[position])
    }

    inner class ViewHolder(private val item: View, homeViewModel: HomeViewModel,
                           private val binding: ItemBookingBinding) : RecyclerView.ViewHolder(item) {
        private lateinit var bookingItem: Booking
        private var userActionsListener: BookingItemSelectedListener = object : BookingItemSelectedListener {
            override fun onCallClicked(number: String) {
                IntentActionUtils.dialPhone(item.context, number)
            }

            override fun onDirectionsClicked(latlng: ArrayList<Double>) {
                if(bookingItem.status==AppConstants.STATUS_PENDING||
                        bookingItem.status==AppConstants.STATUS_CONFIRMED ){
                    MapUtils.openGoogleMapsDirection(item.context,bookingItem.pickupAddress?:"")
                }
                else if(bookingItem.status==AppConstants.STATUS_STARTED){
                    if(bookingItem.serviceTypeActual!=AppConstants.SELECTED_CAR_SERVICE){
                        MapUtils.openGoogleMapsDirection(item.context,bookingItem.dropOffAddress?:"")
                    }
                }
            }

            override fun onBookingSelected(bookingItem: Booking) {
                bookingItem.isSelected = !bookingItem.isSelected
                notifyItemChanged(adapterPosition)
            }


            override fun onAddDoc(bookingId: String?) {
                homeViewModel.onAddDoc(bookingItem)
            }

            override fun onStatusChange(bookingItem: Booking) {
                if (bookingItem.status != AppConstants.STATUS_DELIVERED &&
                        bookingItem.status != AppConstants.STATUS_DELIVERED_TO_USER) {
                    val isTripAlreadyThere = PrefsManager.get().getBoolean(PrefsManager.PREF_IS_ANY_TRIP_STARTED,
                            false)
                    val bookingId = PrefsManager.get().getString(PrefsManager.PREF_BOOKING_ID, "")
                    if (!isTripAlreadyThere || bookingItem.bookingId == bookingId) {
                        homeViewModel.getLocationPermission(bookingItem)
                    } else {
                        item.context.getString(R.string.error_trip_already_there)
                    }
                }
            }
        }

        init {
        }

        fun bind(bookingItem: Booking) {
            this.bookingItem = bookingItem
            item.rvDocuments.layoutManager=LinearLayoutManager(item.context,LinearLayoutManager.HORIZONTAL,false)
            item.rvDocuments.adapter = AddDocAdapter(homeViewModel, bookingItem)
            with(binding) {
                bookingData = bookingItem
                listener = userActionsListener
                executePendingBindings()
            }
        }
    }

    fun setBookingList(bookingsList: ArrayList<Booking>) {
        this.bookingsList.clear()
        this.bookingsList.addAll(bookingsList)
        notifyDataSetChanged()
    }

}