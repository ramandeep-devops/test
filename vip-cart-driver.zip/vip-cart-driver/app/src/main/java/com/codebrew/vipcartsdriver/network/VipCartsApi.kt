package com.codebrew.vipcartsdriver.network

import com.codebrew.vipcartsdriver.model.ApiResponse
import com.codebrew.vipcartsdriver.model.Booking
import com.codebrew.vipcartsdriver.model.LoginRequest
import com.codebrew.vipcartsdriver.model.ResponseLogin
import com.codebrew.vipcartsdriver.model.bookingItem.DocumentsItem
import com.codebrew.vipcartsdriver.model.bookingItem.ResponseBooking
import com.codebrew.vipcartsdriver.utils.ApiConstants
import okhttp3.MultipartBody
import okhttp3.RequestBody
import retrofit2.Call
import retrofit2.http.*

interface VipCartsApi {

    @POST(ApiConstants.ENDPOINT_LOGIN)
    fun login(@Body request: LoginRequest): Call<ApiResponse<ResponseLogin>>

    @FormUrlEncoded
    @POST(ApiConstants.ENDPOINT_GET_BOOKINGS)
    fun getBookings(@Header(ApiConstants.PARAM_AUTHORIZATION) paramsAuth: String,
                    @Field(ApiConstants.PARAM_DATE) date: String):
            Call<ApiResponse<ArrayList<ResponseBooking>>>


    @Multipart
    @POST(ApiConstants.ENDPOINT_UPLOAD_DOCS)
    fun uploadDocs(@Header(ApiConstants.PARAM_AUTHORIZATION) paramsAuth: String,
                   @Part(ApiConstants.PARAM_BOOKING_ID) bookingId: RequestBody,
                   @Part file: MultipartBody.Part):
            Call<ApiResponse<ArrayList<DocumentsItem>>>

    @FormUrlEncoded
    @POST(ApiConstants.ENDPOINT_TRACKING)
    fun driverTrack(@Header(ApiConstants.PARAM_AUTHORIZATION) paramsAuth: String,
                   @Field(ApiConstants.PARAM_BOOKING_ID) bookingId: String,
                   @Field(ApiConstants.PARAM_LATITUDE) lat: Double,
                   @Field(ApiConstants.PARAM_LONGITUDE) lng: Double):
            Call<ApiResponse<Any>>

    @FormUrlEncoded
    @POST(ApiConstants.ENDPOINT_STATUS_CHANGE)
    fun changeTripStatus(@Header(ApiConstants.PARAM_AUTHORIZATION) paramsAuth: String,
                   @Field(ApiConstants.PARAM_BOOKING_ID) bookingId: String,
                   @Field(ApiConstants.PARAM_STATUS) status: Int):
            Call<ApiResponse<Any>>

}