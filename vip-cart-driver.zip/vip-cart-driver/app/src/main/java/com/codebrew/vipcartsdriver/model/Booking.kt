package com.codebrew.vipcartsdriver.model

import android.support.annotation.StringRes
import com.codebrew.vipcartsdriver.model.bookingItem.DocumentsItem


data class Booking(val dropOffAddress: String? = null,
                   val dropOffTme: String? = null,
                   var isSelected: Boolean = false,
                   val pickupAddress: String? = null,
                   val pickupTime: String? = null,
                   val bookingId: String? = null,
                   val name: String? = null,
                   var status: String? = null,
                   val contact: String? = null,
                   var serviceTypeActual: Int? = null,
                   @StringRes var statusFormatted: Int? = null,
                   @StringRes var statusChange: Int? = null,
                   @StringRes var serviceType: Int? = null,
                   val latlng: ArrayList<Double?> = ArrayList(),
                   val listImages: ArrayList<DocumentsItem?> = ArrayList())