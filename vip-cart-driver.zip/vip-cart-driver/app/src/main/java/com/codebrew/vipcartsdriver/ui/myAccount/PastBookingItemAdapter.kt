package com.codebrew.vipcartsdriver.ui.myAccount

import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.telephony.PhoneNumberUtils
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.codebrew.vipcartsdriver.R
import com.codebrew.vipcartsdriver.model.Booking
import com.codebrew.vipcartsdriver.model.bookingItem.DocumentsItem
import com.codebrew.vipcartsdriver.utils.AppConstants
import com.codebrew.vipcartsdriver.utils.IntentActionUtils
import com.codebrew.vipcartsdriver.utils.PrefsManager
import com.codebrew.vipcartsdriver.utils.ch
import com.codebrew.vipcartsdriver.ui.myAccount.*
import com.kbeanie.multipicker.utils.IntentUtils
import com.codebrew.vipcartsdriver.databinding.ItemBookingBinding
import com.codebrew.vipcartsdriver.ui.home.BookingItemSelectedListener
import kotlinx.android.synthetic.main.item_booking.view.*

class PastBookingItemAdapter(private val bookingsList : ArrayList<Booking>) : RecyclerView.Adapter<PastBookingItemAdapter.ViewHolder>() {

    private lateinit var binding: ItemBookingBinding
    override fun onCreateViewHolder(parent: ViewGroup?, viewType: Int): ViewHolder {
        binding = ItemBookingBinding.inflate(LayoutInflater.from(parent?.context), parent,
                false)
        return ViewHolder(binding.root, binding)
    }

    override fun getItemCount(): Int = bookingsList.size

    override fun onBindViewHolder(holder: ViewHolder?, position: Int) {
        holder?.bind(bookingsList[position])
    }

    inner class ViewHolder(private val item: View,
                           private val binding: ItemBookingBinding) : RecyclerView.ViewHolder(item) {
        private lateinit var bookingItem: Booking
        private var userActionsListener: BookingItemSelectedListener = object : BookingItemSelectedListener {
            override fun onCallClicked(number: String) {
            }

            override fun onDirectionsClicked(latlng: ArrayList<Double>) {
            }

            override fun onBookingSelected(bookingItem: Booking) {
                bookingItem.isSelected = !bookingItem.isSelected
                notifyItemChanged(adapterPosition)
            }


            override fun onAddDoc(bookingId: String?) {
            }

            override fun onStatusChange(bookingItem: Booking) {

            }
        }

        init {
        }

        fun bind(bookingItem: Booking) {
            this.bookingItem = bookingItem
            item.rvDocuments.layoutManager=LinearLayoutManager(item.context,
                    LinearLayoutManager.HORIZONTAL,false)
            item.rvDocuments.adapter = DocsAdapter(bookingItem.listImages)
            with(binding) {
                bookingData = bookingItem
                listener = userActionsListener
                executePendingBindings()
            }
        }
    }


}