package com.codebrew.vipcartsdriver.model


data class LoginRequest(val email: String,
                        val password: String,
                        val deviceType: String,
                        var deviceToken: String

)