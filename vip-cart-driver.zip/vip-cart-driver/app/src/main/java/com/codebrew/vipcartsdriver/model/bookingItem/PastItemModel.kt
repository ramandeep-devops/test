package com.codebrew.vipcartsdriver.model.bookingItem

import com.codebrew.vipcartsdriver.model.Booking
import com.google.gson.annotations.SerializedName


data class PastItemModel(@field:SerializedName("_id")
                         val date: String? = null,

                         @field:SerializedName("bookings")
                         val bookings: ArrayList<Booking> = ArrayList())