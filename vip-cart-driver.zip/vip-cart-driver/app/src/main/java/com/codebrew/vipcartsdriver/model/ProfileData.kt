package com.codebrew.vipcartsdriver.model

import com.codebrew.vipcartsdriver.model.bookingItem.PastItemModel
import com.google.gson.annotations.SerializedName


data class ProfileData(
        @field:SerializedName("firstName")
        val firstName: String? = null,

        @field:SerializedName("lastName")
        val lastName: String? = null,

        @field:SerializedName("email")
        val email: String? = null,

        @field:SerializedName("countryId")
        val countryId: String? = null,

        @field:SerializedName("phoneNumber")
        val phoneNumber: String? = null,

        @field:SerializedName("dob")
        val dob: String? = null,

        @field:SerializedName("imageUrl")
        val imageUrl: ImageUrl? = null,

        @field:SerializedName("past")
        val past: ArrayList<PastItemModel> = ArrayList(),

        @field:SerializedName("isBlocked")
        val isBlocked: Boolean? = null,

        @field:SerializedName("countryCode")
        val countryCode: String? = null,

        @field:SerializedName("_id")
        val id: String? = null
)