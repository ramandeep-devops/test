package com.codebrew.vipcartsdriver.model.bookingItem

import com.google.gson.annotations.SerializedName

data class RiderLocationItem(

	@field:SerializedName("_id")
	val id: String? = null,

	@field:SerializedName("long")
	val jsonMemberLong: Double? = null,

	@field:SerializedName("lat")
	val lat: Double? = null
)