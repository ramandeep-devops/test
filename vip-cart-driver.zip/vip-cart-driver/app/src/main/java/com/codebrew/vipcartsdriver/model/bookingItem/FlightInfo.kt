package com.codebrew.vipcartsdriver.model.bookingItem

import com.google.gson.annotations.SerializedName

data class FlightInfo(

	@field:SerializedName("arrivalTime")
	val arrivalTime: String? = null,

	@field:SerializedName("flightNumber")
	val flightNumber: String? = null
)