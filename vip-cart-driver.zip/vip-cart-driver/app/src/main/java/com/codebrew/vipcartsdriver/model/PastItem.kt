package com.codebrew.vipcartsdriver.model

import com.codebrew.vipcartsdriver.model.bookingItem.ResponseBooking
import com.google.gson.annotations.SerializedName

data class PastItem(

		@field:SerializedName("_id")
		val date: Long? = null,

		@field:SerializedName("bookings")
		val bookings: ArrayList<ResponseBooking>? = null
)