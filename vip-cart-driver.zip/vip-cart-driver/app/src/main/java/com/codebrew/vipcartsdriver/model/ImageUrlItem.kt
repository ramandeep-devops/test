package com.codebrew.vipcartsdriver.model

import com.google.gson.annotations.SerializedName

data class ImageUrlItem(

	@field:SerializedName("thumbnail")
	val thumbnail: String? = null,

	@field:SerializedName("original")
	val original: String? = null,

	@field:SerializedName("_id")
	val id: String? = null
)