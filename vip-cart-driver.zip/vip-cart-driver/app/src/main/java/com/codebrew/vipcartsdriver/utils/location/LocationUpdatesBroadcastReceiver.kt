package com.codebrew.vipcartsdriver.utils.location

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import android.widget.Toast
import com.codebrew.vipcartsdriver.model.ApiResponse
import com.codebrew.vipcartsdriver.network.RetrofitClient
import com.codebrew.vipcartsdriver.utils.AppConstants
import com.codebrew.vipcartsdriver.utils.PrefsManager

import com.google.android.gms.location.LocationResult
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class LocationUpdatesBroadcastReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent?) {
        if (intent != null) {
            val action = intent.action
            if (ACTION_PROCESS_UPDATES == action) {
                val result = LocationResult.extractResult(intent)
                if (result != null) {
                    val locations = result.locations
                    val lat: Double
                    val lng: Double
                    if (locations.size > 0) {
                        lat = locations[locations.size - 1].latitude
                        lng = locations[locations.size - 1].longitude
                        PrefsManager.get().save(PrefsManager.PREF_LOCATION_LATITUDE, lat)
                        PrefsManager.get().save(PrefsManager.PREF_LOCATION_LONGITUDE, lng)
                        trackDriver(lat,lng)
                    }
                }
            }
        }
    }

    private fun trackDriver(lat: Double, lng: Double) {
        val bookingId=PrefsManager.get().getString(PrefsManager.PREF_BOOKING_ID, "")

        RetrofitClient.getApi().driverTrack(PrefsManager.get().getString(PrefsManager.PREF_API_TOKEN, "")
                , bookingId, lat, lng).enqueue(object : Callback<ApiResponse<Any>> {

            override fun onFailure(call: Call<ApiResponse<Any>>?, t: Throwable?) {
                t?.printStackTrace()
            }

            override fun onResponse(call: Call<ApiResponse<Any>>?,
                                    response: Response<ApiResponse<Any>>?) {
                if (response?.isSuccessful == true) {
                    Log.e("latlng",""+lat)
                }
                else{
                    Log.e("fail","fail")

                }
            }
        })

    }

    companion object {
        internal const val ACTION_PROCESS_UPDATES = "com.codebrew.vipcartsdriver.utils.location.action" + ".PROCESS_UPDATES"
    }
}
