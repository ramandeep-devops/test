package com.codebrew.vipcartsdriver.ui.myAccount


import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.support.v4.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.codebrew.vipcartsdriver.databinding.LayoutProfileBinding
import com.codebrew.vipcartsdriver.model.ProfileData
import com.codebrew.vipcartsdriver.ui.login.LoginActivity
import com.codebrew.vipcartsdriver.ui.myAccount.*
import com.codebrew.vipcartsdriver.utils.PrefsManager
import com.codebrew.vipcartsdriver.utils.ch
import kotlinx.android.synthetic.main.layout_profile.*

class MyAccountFragment : Fragment() {
    private lateinit var binding:LayoutProfileBinding
    private var profile:ProfileData?=null

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View? {
        binding=LayoutProfileBinding.inflate(inflater,container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        profile=PrefsManager.get().getObject(PrefsManager.PREF_USER_PROFILE,
                ProfileData::class.java)
        with(binding){
            profileData= profile
        }
        setToolbar()
        setAdapter()
    }

    private fun setAdapter() {
        rvPastBookings.adapter= PastBookingAdapter(ch(profile?.past))
    }


    private fun setToolbar() {
        toolbar.setNavigationOnClickListener {
            activity?.supportFragmentManager?.popBackStack()
        }

        tvSignOut.setOnClickListener {
            PrefsManager.get().removeAll()
            activity?.finishAffinity()
            activity?.startActivity(Intent(activity, LoginActivity::class.java))
        }

    }

    override fun onAttach(context: Context?) {
        super.onAttach(context)
    }

}
