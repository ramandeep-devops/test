package com.codebrew.vipcartsdriver.model

import com.google.gson.annotations.SerializedName

data class ServiceId(

	@field:SerializedName("code")
	val code: Int? = null,

	@field:SerializedName("_id")
	val id: String? = null
)