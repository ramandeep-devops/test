package com.codebrew.vipcartsdriver.model

import com.google.gson.annotations.SerializedName

data class ResponseLogin(

        @field:SerializedName("deviceType")
        val deviceType: String? = null,

        @field:SerializedName("lastName")
        val lastName: String? = null,

        @field:SerializedName("supplierId")
        val supplierId: String? = null,

        @field:SerializedName("past")
        val past: List<PastItem?>? = null,

        @field:SerializedName("isBlocked")
        val isBlocked: Boolean? = null,

        @field:SerializedName("title")
        val title: String? = null,

        @field:SerializedName("accessToken")
        val accessToken: String? = null,

        @field:SerializedName("countryId")
        val countryId: String? = null,

        @field:SerializedName("deviceToken")
        val deviceToken: String? = null,

        @field:SerializedName("firstName")
        val firstName: String? = null,

        @field:SerializedName("password")
        val password: String? = null,

        @field:SerializedName("phoneNumber")
        val phoneNumber: String? = null,

        @field:SerializedName("isDeleted")
        val isDeleted: Boolean? = null,

        @field:SerializedName("countryCode")
        val countryCode: String? = null,

        @field:SerializedName("dob")
        val dob: String? = null,

        @field:SerializedName("imageUrl")
        val imageUrl: ImageUrl? = null,

        @field:SerializedName("__v")
        val V: Int? = null,

        @field:SerializedName("registrationDate")
        val registrationDate: Long? = null,

        @field:SerializedName("location")
        val location: List<Double?>? = null,

        @field:SerializedName("_id")
        val id: String? = null,

        @field:SerializedName("email")
        val email: String? = null
)