package com.codebrew.vipcartsdriver.utils

import android.content.Context
import android.util.AttributeSet
import android.view.LayoutInflater
import android.view.View
import android.widget.LinearLayout
import com.codebrew.vipcartsdriver.R
import kotlinx.android.synthetic.main.layout_no_data_found.view.*

class NoDataFoundView : LinearLayout
{
    private var listener: OnRefreshClickListener? = null

    constructor(context: Context) : super(context, null)

    constructor(context: Context, attrs: AttributeSet) : super(context, attrs)
    {
        // Attach the inflated layout to the root
        LayoutInflater.from(context).inflate(R.layout.layout_no_data_found, this, true)

        // Set the attribute values to the views
        val typedArray = context.obtainStyledAttributes(attrs, R.styleable.NoDataFoundView, 0, 0)
        if (typedArray.hasValue(R.styleable.NoDataFoundView_message))
        {
            tvMessage.text = typedArray.getString(R.styleable.NoDataFoundView_message)
        }

        if (typedArray.hasValue(R.styleable.NoDataFoundView_image))
        {
            val drawableTop = typedArray.getResourceId(R.styleable.NoDataFoundView_image, 0)
            tvMessage.setCompoundDrawablesRelativeWithIntrinsicBounds(0, drawableTop, 0, 0)
        }

        if (typedArray.hasValue(R.styleable.NoDataFoundView_showRefresh))
        {
            val showRefresh = typedArray.getBoolean(R.styleable.NoDataFoundView_showRefresh, true)
            btnRefresh.visibility = if (showRefresh) View.VISIBLE else View.GONE
        }
        typedArray.recycle()

        btnRefresh.setOnClickListener {
            listener?.onRefreshClicked()
        }
    }

    fun setListener(listener: OnRefreshClickListener?)
    {
        this.listener = listener
    }

    interface OnRefreshClickListener
    {
        fun onRefreshClicked()
    }

    fun setMessageWithImage(msg: String, drawableId: Int) {
        tvMessage.apply {
            text = msg
            setCompoundDrawablesRelativeWithIntrinsicBounds(0, drawableId, 0, 0)
        }
    }

    fun setMessage(msg: String) {
        tvMessage.text = msg
    }
}