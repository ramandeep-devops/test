package com.codebrew.vipcartsdriver.ui.myAccount

import android.support.v7.widget.RecyclerView
import android.telephony.PhoneNumberUtils
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.codebrew.vipcartsdriver.R
import com.codebrew.vipcartsdriver.databinding.ItemPastBookingBinding
import com.codebrew.vipcartsdriver.model.Booking
import com.codebrew.vipcartsdriver.model.bookingItem.DocumentsItem
import com.codebrew.vipcartsdriver.model.bookingItem.PastItemModel
import com.codebrew.vipcartsdriver.ui.myAccount.PastBookingItemAdapter
import com.codebrew.vipcartsdriver.utils.AppConstants
import com.codebrew.vipcartsdriver.utils.IntentActionUtils
import com.codebrew.vipcartsdriver.utils.PrefsManager
import com.codebrew.vipcartsdriver.utils.ch
import com.kbeanie.multipicker.utils.IntentUtils
import kotlinx.android.synthetic.main.item_past_booking.view.*

class PastBookingAdapter(private var bookingsList:ArrayList<PastItemModel>) :
        RecyclerView.Adapter<PastBookingAdapter.ViewHolder>() {

    private var pastItemList = bookingsList
    private lateinit var binding: ItemPastBookingBinding
    override fun onCreateViewHolder(parent: ViewGroup?, viewType: Int): ViewHolder {
        binding = ItemPastBookingBinding.inflate(LayoutInflater.from(parent?.context), parent,
                false)
        return ViewHolder(binding.root, binding)
    }

    override fun getItemCount(): Int = bookingsList.size

    override fun onBindViewHolder(holder: ViewHolder?, position: Int) {
        holder?.bind(bookingsList[position])
    }

    inner class ViewHolder(private val item: View,
                           private val binding: ItemPastBookingBinding) : RecyclerView.ViewHolder(item) {
        private lateinit var bookingItem: PastItemModel

        fun bind(bookingItem: PastItemModel) {
            this.bookingItem = bookingItem
            item.rvPastBookings.adapter = PastBookingItemAdapter(bookingItem.bookings)
            with(binding) {
                pastBooking = bookingItem
                executePendingBindings()
            }
        }
    }

    fun setBookingList(bookingsList: ArrayList<PastItemModel>) {
        this.pastItemList.clear()
        this.pastItemList.addAll(bookingsList)
        notifyDataSetChanged()
    }

}