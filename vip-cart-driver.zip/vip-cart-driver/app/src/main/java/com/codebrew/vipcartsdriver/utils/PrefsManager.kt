package com.codebrew.vipcartsdriver.utils

import android.content.Context
import android.content.SharedPreferences
import android.support.annotation.StringDef
import com.google.gson.Gson
import java.util.concurrent.atomic.AtomicBoolean

class PrefsManager private constructor(context: Context)
{
    private val PREF_NAME = "VipCartDriver"
    private val GSON = Gson()
    private var preferences: SharedPreferences

    companion object
    {
        const val PREF_USER_PROFILE = "PREF_USER_PROFILE"
        const val PREF_API_TOKEN = "PREF_API_TOKEN"
        const val PREF_DEVICE_TOKEN = "PREF_DEVICE_TOKEN"
        const val PREF_LANGUAGE = "PREF_LANGUAGE"
        const val PREF_LANGUAGE_CODE = "PREF_LANGUAGE_CODE"
        const val PREF_USER_TYPE= "PREF_USER_TYPE"
        const val PREF_COUNTRIES_SERVICES= "PREF_COUNTRIES_SERVICES"
        const val PREF_COUNTRIES_SELECTED= "PREF_COUNTRIES_SELECTED"
        const val PREF_CURRENCY= "PREF_CURRENCY"
        const val PREF_FILTER= "PREF_FILTER"
        const val PREF_FILTER_SEATS= "PREF_FILTER_SEATS"
        const val PREF_FILTER_CONVERTIBLE= "PREF_FILTER_CONVERTIBLE"
        const val PREF_IS_ANY_TRIP_STARTED= "PREF_IS_ANY_TRIP_STARTED"
        const val PREF_LOCATION_LATITUDE= "PREF_LOCATION_LATITUDE"
        const val PREF_LOCATION_LONGITUDE= "PREF_LOCATION_LONGITUDE"
        const val PREF_LOCATION_REQUESTING= "PREF_LOCATION_REQUESTING"
        const val PREF_BOOKING_ID= "PREF_BOOKING_ID"


        @StringDef(PREF_FILTER_CONVERTIBLE,PREF_FILTER_SEATS,
                PREF_FILTER,PREF_CURRENCY,PREF_COUNTRIES_SELECTED,
                PREF_COUNTRIES_SERVICES,PREF_USER_PROFILE,
                PREF_API_TOKEN,PREF_USER_TYPE,PREF_LANGUAGE,PREF_LANGUAGE_CODE,
                PREF_IS_ANY_TRIP_STARTED,PREF_BOOKING_ID)
        @Retention(AnnotationRetention.SOURCE)
        annotation class PrefKey

        private lateinit var instance: PrefsManager
        private val isInitialized = AtomicBoolean()     // To check if instance was previously initialized or not

        fun initialize(context: Context)
        {
            if (!isInitialized.getAndSet(true))
            {
                instance = PrefsManager(context.applicationContext)
            }
        }

        fun get(): PrefsManager = instance
    }

    init
    {
        preferences = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
    }

    fun save(@PrefKey key: String, value: String)
    {
        preferences.edit().putString(key, value).apply()
    }

    fun save(@PrefKey key: String, value: Int)
    {
        preferences.edit().putInt(key, value).apply()
    }

    fun save(@PrefKey key: String, value: Boolean)
    {
        preferences.edit().putBoolean(key, value).apply()
    }

    fun save(@PrefKey key: String, `object`: Any?)
    {
        if (`object` == null)
        {
            throw IllegalArgumentException("object is null")
        }

        // Convert the provided object to JSON string
        save(key, GSON.toJson(`object`))
    }

    fun getString(@PrefKey key: String, defValue: String): String = preferences.getString(key, defValue)

    fun getInt(@PrefKey key: String, defValue: Int): Int = preferences.getInt(key, defValue)

    fun getBoolean(@PrefKey key: String, defValue: Boolean): Boolean = preferences.getBoolean(key, defValue)

    fun <T> getObject(@PrefKey key: String, objectClass: Class<T>): T?
    {
        val jsonString = preferences.getString(key, null)
        return if (jsonString == null)
        {
            null
        }
        else
        {
            try
            {
                GSON.fromJson(jsonString, objectClass)
            }
            catch (e: Exception)
            {
                throw IllegalArgumentException("Object stored with key $key is instance of other class")
            }
        }
    }

    fun removeAll()
    {
        preferences.edit().clear().apply()
    }

    fun remove(key: String)
    {
        preferences.edit().remove(key).apply()
    }
}