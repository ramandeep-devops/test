package com.codebrew.vipcartsdriver.utils

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.support.v4.content.ContextCompat.startActivity



object MapUtils
{
    fun getGoogleStaticMapUrl(latitude: String, longitude: String): String
            = "https://maps.googleapis.com/maps/api/staticmap?center=$latitude,$longitude&zoom=8&size=300x300&scale=2&markers=color:yellow%7C$latitude,$longitude&key=AIzaSyAnE6Xv13FD1jANdHGOL5xzp04at6D3RMw"

    fun openGoogleMaps(context: Context, latitude: String, longitude: String)
    {
        val intentUri = Uri.parse("https://www.google.com/maps/search/?api=1&query=$latitude,$longitude")
        val mapIntent = Intent(Intent.ACTION_VIEW, intentUri)

        // Open in google maps app if available
        mapIntent.`package` = "com.google.android.apps.maps"
        if (mapIntent.resolveActivity(context.packageManager) != null)
        {
            context.startActivity(mapIntent)
        }
        else
        {
            // If google maps is not available, then open in browser
            mapIntent.`package` = null
            if (mapIntent.resolveActivity(context.packageManager) != null)
            {
                context.startActivity(mapIntent)
            }
        }
    }
    fun openGoogleMapsDirection(context: Context,address: String)
    {
        val gmmIntentUri = Uri.parse("google.navigation:q="+address)
        val mapIntent = Intent(Intent.ACTION_VIEW, gmmIntentUri)

        // Open in google maps app if available
        mapIntent.`package` = "com.google.android.apps.maps"
        if (mapIntent.resolveActivity(context.packageManager) != null)
        {
            context.startActivity(mapIntent)
        }
        else
        {
            // If google maps is not available, then open in browser
            mapIntent.`package` = null
            if (mapIntent.resolveActivity(context.packageManager) != null)
            {
                context.startActivity(mapIntent)
            }
        }
    }
}