package com.codebrew.vipcartsdriver.model.bookingItem

import com.google.gson.annotations.SerializedName

data class ResponseBooking(

		@field:SerializedName("notes")
	val notes: String? = null,

		@field:SerializedName("numberPlateId")
	val numberPlateId: Any? = null,

		@field:SerializedName("supplierId")
	val supplierId: String? = null,

		@field:SerializedName("distance")
	val distance: Int? = null,

		@field:SerializedName("documents")
	val documents: ArrayList<DocumentsItem?>? = ArrayList(),

		@field:SerializedName("purpose")
	val purpose: String? = null,

		@field:SerializedName("airportId")
	val airportId: Any? = null,

		@field:SerializedName("rating")
	val rating: Int? = null,

		@field:SerializedName("createdOn")
	val createdOn: Long? = null,

		@field:SerializedName("paymentType")
	val paymentType: Int? = null,

		@field:SerializedName("dropOffAddress")
	val dropOffAddress: String? = null,

		@field:SerializedName("cancelByDriver")
	val cancelByDriver: Boolean? = null,

		@field:SerializedName("amountPaid")
	val amountPaid: Double? = null,

		@field:SerializedName("cancelByUser")
	val cancelByUser: Boolean? = null,

		@field:SerializedName("__v")
	val V: Int? = null,

		@field:SerializedName("dropOffDate")
	val dropOffDate: Long? = null,

		@field:SerializedName("flightInfo")
	val flightInfo: FlightInfo? = null,

		@field:SerializedName("pickUpAddress")
	val pickUpAddress: String? = null,

		@field:SerializedName("riderLocation")
	val riderLocation: List<RiderLocationItem?>? = null,

		@field:SerializedName("userId")
	val userId: UserId? = null,

		@field:SerializedName("bookingId")
	val bookingId: String? = null,

		@field:SerializedName("carId")
	val carId: CarId? = null,

		@field:SerializedName("amountDue")
	val amountDue: Int? = null,

		@field:SerializedName("isPaid")
	val isPaid: Boolean? = null,

		@field:SerializedName("pickUpDate")
	val pickUpDate: Long? = null,

		@field:SerializedName("driverId")
	val driverId: String? = null,

		@field:SerializedName("_id")
	val id: String? = null,

		@field:SerializedName("status")
	val status: String? = null
)